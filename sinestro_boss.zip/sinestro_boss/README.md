# Sinestro Boss (Fabric 1.20.1)

Requiere: Fabric Loader, Fabric API y A New Corps (+ Palladium, GeckoLib, KubeJS, Trinkets que ese addon ya pide).

## Compilar sin PC (GitHub Actions)
1. Sube TODO el contenido de esta carpeta a un repositorio de GitHub (incluida la carpeta oculta .github).
2. Pestaña Actions -> "build" (se ejecuta sola al subir, o Run workflow).
3. Descarga el artefacto "sinestro_boss": dentro está el .jar (usa el que NO termina en -sources).
4. Ponlo en la carpeta mods.

## Contenido
- Jefe Sinestro con 3 fases (transiciones únicas, la fase se guarda en el mundo).
- Habilidades: proyectil, ráfaga, rayo, Nova, ataque descendente, impulso aéreo, puño de energía, jaula, escudo y contraataque.
- Armas: espada, hacha y escoba de energía amarilla (el jefe suelta una al azar).
- Voces: ver VOCES.md.
- Configuración: config/sinestro_boss.json (se crea al abrir el juego por primera vez).
- Invocar: huevo generador (creativo) o Tótem del Miedo (8 bloques de oro + 1 estrella del Nether).
- No funciona en dificultad Pacífica.
