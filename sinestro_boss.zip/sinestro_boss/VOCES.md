# Voces de Sinestro

Los audios los pones tú. Formato **.ogg** (mono, 44.1 kHz o 22 kHz si quieres que pesen poco).
Colócalos en `src/main/resources/assets/sinestro_boss/sounds/voice/` con estos nombres exactos:

| Archivo | Cuándo suena |
|---|---|
| `idle.ogg` | Reposo (sin objetivo), con probabilidad y espera largas |
| `attack.ogg` | Al iniciar proyectil, ráfaga o rayo |
| `special.ogg` | Nova, ataque descendente, puño, jaula, escudo |
| `hurt.ogg` | Al recibir daño (con tiempo de espera) |
| `phase.ogg` | Al cambiar de fase (siempre suena) |
| `death.ogg` | Al morir (siempre suena) |

- Los eventos están registrados como `sinestro_boss:voice.idle`, `voice.attack`, etc. y declarados en `assets/sinestro_boss/sounds.json`.
- Si un archivo falta, el evento queda en silencio y al abrir el juego aparece un aviso `[Sinestro] Falta el audio de voz` en el log. No causa cierres.
- Probabilidades y esperas se ajustan en `config/sinestro_boss.json` (`voiceIdleChance`, `voiceAttackChance`, `voiceSpecialChance`, `voiceHurtChance`, `voiceHurtCooldown`, `voiceGlobalCooldown`, `voiceIdleCooldown`).
- Para varias variantes de un evento, añade más entradas en el arreglo `sounds` de `sounds.json` (por ejemplo `voice/attack_2`).
