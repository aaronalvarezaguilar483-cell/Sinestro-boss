package com.sinestroboss.entity;

import com.sinestroboss.ModSounds;
import com.sinestroboss.config.SinestroConfig;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.VexEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Sinestro: jefe volador con IA propia, 3 fases y habilidades con tiempos de espera.
 * Las construcciones (jaula, puño, escudo, domo) son efectos virtuales hechos con partículas
 * y comprobaciones por tick: no crean bloques ni entidades extra (salvo los vex invocados).
 */
public class SinestroEntity extends HostileEntity {
    public enum Ability { BOLT, VOLLEY, BEAM, NOVA, DIVE, DASH, FIST, CAGE }

    public static final int POSE_NONE = 0;
    public static final int POSE_RAISE = 1;
    public static final int POSE_POINT = 2;
    public static final int POSE_SLAM = 3;
    public static final int POSE_PLUNGE = 4;

    private static final int TRANSITION_TOTAL = 40;
    private static final TrackedData<Integer> COMBAT_POSE =
            DataTracker.registerData(SinestroEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private static final UUID ENRAGE_SPEED_ID = UUID.fromString("5f4a3d1c-8b22-4c7e-9a61-2f0c7d9e1a11");
    private static final UUID ENRAGE_FLY_ID = UUID.fromString("a2c91e47-3d85-4b0f-8e12-6b7f50c4d922");

    private static final DustParticleEffect YELLOW = new DustParticleEffect(new Vector3f(1.0f, 0.85f, 0.05f), 1.4f);
    private static final DustParticleEffect YELLOW_BIG = new DustParticleEffect(new Vector3f(1.0f, 0.9f, 0.1f), 2.4f);
    private static final DustParticleEffect GOLD = new DustParticleEffect(new Vector3f(1.0f, 0.65f, 0.0f), 1.6f);
    /** Naranja-rojo: se usa SOLO para avisar de ataques (zonas de impacto, líneas de rayo). */
    private static final DustParticleEffect TELEGRAPH = new DustParticleEffect(new Vector3f(1.0f, 0.35f, 0.05f), 1.3f);

    private final ServerBossBar bossBar =
            new ServerBossBar(this.getDisplayName(), BossBar.Color.YELLOW, BossBar.Style.PROGRESS);
    private final List<VexEntity> minions = new ArrayList<>();
    private final int[] cooldowns = new int[Ability.values().length];

    private int phase = 1;
    private int transitionTicks = 0;
    private Ability current = null;
    private int abilityTick = 0;
    private int globalCooldown = 40;
    private Vec3d aim = Vec3d.ZERO;
    private Vec3d lockedPos = Vec3d.ZERO;
    private Vec3d dashDir = Vec3d.ZERO;
    private int volleyFired = 0;

    private int minionCooldown = 100;
    private int shieldCooldown = 0;
    private int shieldTicks = 0;
    private int counterCooldown = 0;
    private int hurtVoiceCd = 0;
    private int idleVoiceCd = 200;
    private int voiceGlobalCd = 0;
    private int auraCooldown = 0;
    private int lastSfxAge = -100;
    private float recentDamage = 0.0f;

    private UUID cageTarget = null;
    private Vec3d cageCenter = Vec3d.ZERO;
    private int cageTicks = 0;

    private Vec3d stuckAnchor = Vec3d.ZERO;
    private int stuckTicks = 0;
    private int unstuckTicks = 0;

    private boolean enraged = false;
    private float lean = 0.0f;
    private float prevLean = 0.0f;

    public SinestroEntity(EntityType<? extends SinestroEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 10, true);
        this.setNoGravity(true);
        this.setPersistent();
        this.experiencePoints = 500;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        SinestroConfig cfg = SinestroConfig.get();
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, cfg.maxHealth)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, cfg.meleeDamage)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(COMBAT_POSE, POSE_NONE);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new BirdNavigation(this, world);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SinestroCombatGoal(this));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 24.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    // =====================================================================
    //  Accesores usados por la IA de movimiento y el modelo
    // =====================================================================
    public int getPhase() {
        return phase;
    }

    public int getCombatPose() {
        return this.dataTracker.get(COMBAT_POSE);
    }

    private void setCombatPose(int pose) {
        if (this.dataTracker.get(COMBAT_POSE) != pose) {
            this.dataTracker.set(COMBAT_POSE, pose);
        }
    }

    public float getLean() {
        return lean;
    }

    public float getLean(float tickDelta) {
        return MathHelper.lerp(tickDelta, prevLean, lean);
    }

    public boolean isTransitioning() {
        return transitionTicks > 0;
    }

    public int getUnstuckTicks() {
        return unstuckTicks;
    }

    /** true cuando una habilidad (o la transición) controla el movimiento y la IA de persecución debe esperar. */
    public boolean isMovementLocked() {
        if (transitionTicks > 0) {
            return true;
        }
        return current != null && current != Ability.BOLT && current != Ability.VOLLEY;
    }

    public boolean pathBlocked(Vec3d from, Vec3d to) {
        return this.getWorld().raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, this)).getType() != HitResult.Type.MISS;
    }

    // =====================================================================
    //  Tick principal
    // =====================================================================
    @Override
    public void tick() {
        super.tick();
        // Suavizado de la inclinación de vuelo (cliente y servidor).
        prevLean = lean;
        float target = getCombatPose() == POSE_PLUNGE
                ? 1.0f
                : MathHelper.clamp(this.limbAnimator.getSpeed() * 1.2f, 0.0f, 1.0f);
        lean += (target - lean) * 0.25f;

        if (this.getWorld().isClient && this.limbAnimator.getSpeed() > 0.4f
                && this.random.nextFloat() < SinestroConfig.get().particleMultiplier) {
            this.getWorld().addParticle(YELLOW,
                    this.getX() + (this.random.nextDouble() - 0.5) * 0.6,
                    this.getY() + 0.8 + (this.random.nextDouble() - 0.5) * 0.6,
                    this.getZ() + (this.random.nextDouble() - 0.5) * 0.6,
                    0.0, 0.0, 0.0);
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        SinestroConfig cfg = SinestroConfig.get();

        tickCooldowns();
        if (phase >= 3 && !enraged) {
            enrage();
        }
        tickTransition(world, cfg);
        tickShield(world, cfg);
        tickCage(world, cfg);
        tickAmbient(world);

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            cancelAbility();
            if (transitionTicks <= 0) {
                setCombatPose(POSE_NONE);
            }
            tickIdleVoice(cfg);
            return;
        }
        if (transitionTicks > 0) {
            return;
        }

        tickStuck(target);
        if (phase >= 2 && minionCooldown <= 0 && minions.size() < cfg.maxMinions) {
            summonMinions(world, target);
            minionCooldown = cfg.minionCooldown;
        }
        tickFear(world, cfg);
        tickAbility(world, cfg, target);

        if (isMovementLocked() && current != Ability.DIVE && current != Ability.DASH) {
            this.setVelocity(this.getVelocity().multiply(0.6)); // se queda flotando mientras lanza el poder
        }
    }

    private void tickCooldowns() {
        for (int i = 0; i < cooldowns.length; i++) {
            if (cooldowns[i] > 0) cooldowns[i]--;
        }
        if (globalCooldown > 0 && current == null) globalCooldown--;
        if (minionCooldown > 0) minionCooldown--;
        if (shieldCooldown > 0) shieldCooldown--;
        if (counterCooldown > 0) counterCooldown--;
        if (hurtVoiceCd > 0) hurtVoiceCd--;
        if (idleVoiceCd > 0) idleVoiceCd--;
        if (voiceGlobalCd > 0) voiceGlobalCd--;
        recentDamage = Math.max(0.0f, recentDamage - 0.4f);
    }

    // =====================================================================
    //  Fases (cada transición ocurre una sola vez; la fase se guarda en NBT)
    // =====================================================================
    private void tickTransition(ServerWorld world, SinestroConfig cfg) {
        if (transitionTicks > 0) {
            transitionTicks--;
            int elapsed = TRANSITION_TOTAL - transitionTicks;
            setCombatPose(POSE_RAISE);
            if (elapsed % 4 == 0) {
                ring(world, YELLOW_BIG, this.getPos().add(0, 1.0, 0), elapsed * 0.3, 24);
            }
            dust(world, GOLD, this.getX(), this.getY() + 1.0, this.getZ(), 6, 0.6, 0.9, 0.6);
            if (elapsed < 20) {
                this.setVelocity(this.getVelocity().multiply(0.8).add(0, 0.05, 0));
            }
            if (transitionTicks == 0) {
                setCombatPose(POSE_NONE);
            }
            return;
        }
        float ratio = this.getHealth() / this.getMaxHealth();
        if (phase == 1 && ratio <= cfg.phase2Threshold) {
            startTransition(world, 2);
        } else if (phase == 2 && ratio <= cfg.phase3Threshold) {
            startTransition(world, 3);
        }
    }

    private void startTransition(ServerWorld world, int newPhase) {
        phase = newPhase;
        transitionTicks = TRANSITION_TOTAL;
        cancelAbility();
        endCage(world);
        globalCooldown = 30;
        voiceForce(ModSounds.VOICE_PHASE);
        world.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL,
                SoundCategory.HOSTILE, 3.0f, 0.9f);
        // Onda que aleja a los jugadores cercanos, sin daño, para que no queden pegados al jefe.
        for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(7.0),
                this::isValidVictim)) {
            p.takeKnockback(0.9, this.getX() - p.getX(), this.getZ() - p.getZ());
            p.velocityModified = true;
        }
        applyPhaseBar();
        if (newPhase >= 3) {
            enrage();
        }
    }

    private void applyPhaseBar() {
        if (phase >= 3) {
            this.bossBar.setColor(BossBar.Color.RED);
            this.bossBar.setStyle(BossBar.Style.NOTCHED_10);
        } else {
            this.bossBar.setColor(BossBar.Color.YELLOW);
            this.bossBar.setStyle(BossBar.Style.PROGRESS);
        }
    }

    private void enrage() {
        enraged = true;
        addEnrageModifier(EntityAttributes.GENERIC_MOVEMENT_SPEED, ENRAGE_SPEED_ID);
        addEnrageModifier(EntityAttributes.GENERIC_FLYING_SPEED, ENRAGE_FLY_ID);
    }

    private void addEnrageModifier(EntityAttribute attribute, UUID id) {
        EntityAttributeInstance inst = this.getAttributeInstance(attribute);
        if (inst != null && inst.getModifier(id) == null) {
            inst.addTemporaryModifier(new EntityAttributeModifier(id, "Sinestro enrage", 0.4,
                    EntityAttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    // =====================================================================
    //  Selección y ejecución de habilidades
    // =====================================================================
    private boolean ready(Ability a) {
        return cooldowns[a.ordinal()] <= 0;
    }

    private void setCooldown(Ability a, int base) {
        cooldowns[a.ordinal()] = (int) (base * (phase >= 3 ? 0.8 : 1.0));
    }

    private void cancelAbility() {
        current = null;
        abilityTick = 0;
    }

    private void finishAbility() {
        SinestroConfig cfg = SinestroConfig.get();
        int gc = cfg.globalCooldownMin + this.random.nextInt(cfg.globalCooldownMax - cfg.globalCooldownMin + 1);
        globalCooldown = phase >= 3 ? (int) (gc * 0.7) : gc;
        current = null;
        abilityTick = 0;
        setCombatPose(POSE_NONE);
    }

    private Ability chooseAbility(SinestroConfig cfg, LivingEntity t) {
        double dist = this.distanceTo(t);
        boolean los = this.canSee(t);
        Map<Ability, Integer> w = new EnumMap<>(Ability.class);

        if (los && dist > 3.0 && ready(Ability.BOLT)) w.put(Ability.BOLT, 5);
        if (los && dist > 5.0 && ready(Ability.VOLLEY)) w.put(Ability.VOLLEY, 3);
        if (los && dist > 4.0 && dist < cfg.beamRange && ready(Ability.BEAM)) w.put(Ability.BEAM, phase >= 2 ? 4 : 2);
        if (phase >= 2 && dist < 12.0 && ready(Ability.NOVA)) w.put(Ability.NOVA, 3);
        if (phase >= 2 && dist > 7.0 && ready(Ability.DIVE)) w.put(Ability.DIVE, 3);
        if ((dist > 14.0 || dist < 3.0) && ready(Ability.DASH)) w.put(Ability.DASH, dist > 14.0 ? 4 : 3);
        if (phase >= 2 && los && dist < 20.0 && ready(Ability.FIST)) w.put(Ability.FIST, cageTicks > 0 ? 6 : 3);
        if (phase >= 2 && los && dist < 16.0 && cageTicks <= 0 && ready(Ability.CAGE)) w.put(Ability.CAGE, 2);

        int total = 0;
        for (int v : w.values()) total += v;
        if (total <= 0) {
            return null;
        }
        int roll = this.random.nextInt(total);
        for (Map.Entry<Ability, Integer> e : w.entrySet()) {
            roll -= e.getValue();
            if (roll < 0) return e.getKey();
        }
        return null;
    }

    private void startAbility(ServerWorld world, SinestroConfig cfg, Ability a, LivingEntity t) {
        current = a;
        abilityTick = 0;
        volleyFired = 0;
        switch (a) {
            case BOLT -> { setCooldown(a, cfg.boltCooldown); voice(ModSounds.VOICE_ATTACK, cfg.voiceAttackChance); }
            case VOLLEY -> { setCooldown(a, cfg.volleyCooldown); voice(ModSounds.VOICE_ATTACK, cfg.voiceAttackChance); }
            case BEAM -> {
                setCooldown(a, cfg.beamCooldown);
                aim = aimAt(t);
                sfx(SoundEvents.BLOCK_BEACON_POWER_SELECT, 2.0f, 0.7f);
                voice(ModSounds.VOICE_ATTACK, cfg.voiceAttackChance);
            }
            case NOVA -> {
                setCooldown(a, cfg.novaCooldown);
                sfx(SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE, 2.0f, 0.8f);
                voice(ModSounds.VOICE_SPECIAL, cfg.voiceSpecialChance);
            }
            case DIVE -> { setCooldown(a, cfg.diveCooldown); voice(ModSounds.VOICE_SPECIAL, cfg.voiceSpecialChance); }
            case FIST -> { setCooldown(a, cfg.fistCooldown); voice(ModSounds.VOICE_SPECIAL, cfg.voiceSpecialChance); }
            case CAGE -> { setCooldown(a, cfg.cageCooldown); voice(ModSounds.VOICE_SPECIAL, cfg.voiceSpecialChance); }
            case DASH -> {
                setCooldown(a, cfg.dashCooldown);
                chooseDashDirection(t);
                sfx(SoundEvents.ENTITY_PHANTOM_SWOOP, 1.5f, 1.2f);
            }
        }
    }

    private void tickAbility(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        if (current == null) {
            if (globalCooldown > 0) {
                return;
            }
            Ability next = chooseAbility(cfg, t);
            if (next != null) {
                startAbility(world, cfg, next, t);
            }
            return;
        }
        abilityTick++;
        switch (current) {
            case BOLT -> runBolt(world, cfg, t);
            case VOLLEY -> runVolley(world, cfg, t);
            case BEAM -> runBeam(world, cfg, t);
            case NOVA -> runNova(world, cfg);
            case DIVE -> runDive(world, cfg, t);
            case DASH -> runDash(world);
            case FIST -> runFist(world, cfg, t);
            case CAGE -> runCage(world, cfg, t);
        }
    }

    // ---- Proyectil amarillo: se apunta en el tick 4 y dispara en el 8; moverse lo esquiva ----
    private void runBolt(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        setCombatPose(abilityTick < 8 ? POSE_RAISE : POSE_POINT);
        if (abilityTick < 8 && abilityTick % 2 == 0) {
            dust(world, GOLD, this.getX(), this.getEyeY() - 0.2, this.getZ(), 2, 0.3, 0.3, 0.3);
        }
        if (abilityTick == 4) aim = aimAt(t);
        if (abilityTick == 8) fireBolt(world, aim, cfg.boltDamage, 0.7);
        if (phase >= 3) {
            if (abilityTick == 12) aim = aimAt(t);
            if (abilityTick == 14) fireBolt(world, aim, cfg.boltDamage, 0.7);
        }
        if (abilityTick >= (phase >= 3 ? 18 : 12)) finishAbility();
    }

    // ---- Ráfaga: varios disparos separados 6 ticks, con dispersión ----
    private void runVolley(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        setCombatPose(abilityTick < 10 ? POSE_RAISE : POSE_POINT);
        if (abilityTick >= 10 && (abilityTick - 10) % 6 == 0 && volleyFired < cfg.volleyShots) {
            Vec3d d = aimAt(t).add(this.random.nextGaussian() * 0.04, this.random.nextGaussian() * 0.04,
                    this.random.nextGaussian() * 0.04);
            if (d.lengthSquared() > 1.0E-4) {
                fireBolt(world, d.normalize(), cfg.volleyDamage, 0.5);
            }
            volleyFired++;
        }
        if (volleyFired >= cfg.volleyShots && abilityTick >= 10 + 6 * cfg.volleyShots) finishAbility();
    }

    // ---- Rayo: línea de aviso naranja mientras carga; se bloquea los últimos 10 ticks ----
    private void runBeam(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        int charge = cfg.beamChargeTicks;
        int fire = cfg.beamFireTicks;
        Vec3d from = this.getEyePos();
        if (abilityTick < charge) {
            setCombatPose(POSE_RAISE);
            if (abilityTick < charge - 10) aim = aimAt(t);
            if (abilityTick % 3 == 0) {
                traceEntities(world, from, aim, cfg.beamRange, 0.1, TELEGRAPH);
            }
            dust(world, YELLOW_BIG, this.getX(), this.getEyeY(), this.getZ(), 3, 0.4, 0.4, 0.4);
        } else if (abilityTick < charge + fire) {
            setCombatPose(POSE_POINT);
            if (abilityTick == charge) {
                sfx(SoundEvents.BLOCK_BEACON_ACTIVATE, 2.0f, 1.4f);
            }
            Vec3d turned = aim.lerp(aimAt(t), 0.03); // gira despacio: se puede rodear
            if (turned.lengthSquared() > 1.0E-4) aim = turned.normalize();
            if ((abilityTick - charge) % 4 == 0) {
                for (LivingEntity e : traceEntities(world, from, aim, cfg.beamRange, 1.0, YELLOW_BIG)) {
                    hurt(e, cfg.beamDamage);
                }
            } else if (abilityTick % 2 == 0) {
                traceEntities(world, from, aim, cfg.beamRange, 0.1, YELLOW_BIG);
            }
        } else {
            finishAbility();
        }
    }

    // ---- Nova: carga con anillo de aviso en el radio real y onda expansiva ----
    private void runNova(ServerWorld world, SinestroConfig cfg) {
        int charge = cfg.novaChargeTicks;
        Vec3d center = this.getPos().add(0, 0.1, 0);
        if (abilityTick < charge) {
            setCombatPose(POSE_RAISE);
            if (abilityTick % 3 == 0) {
                double frac = (double) abilityTick / charge;
                ring(world, TELEGRAPH, center, cfg.novaRadius, 28);
                ring(world, YELLOW_BIG, center, cfg.novaRadius * frac, 20);
                dust(world, YELLOW_BIG, this.getX(), this.getY() + 1.0, this.getZ(), 6, 1.2, 1.2, 1.2); // domo
            }
        } else if (abilityTick == charge) {
            setCombatPose(POSE_SLAM);
            double r = cfg.novaRadius;
            for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(r),
                    this::isValidVictim)) {
                double dist = e.getPos().distanceTo(this.getPos());
                if (dist <= r) {
                    hurt(e, cfg.novaDamage * (1.0 - 0.5 * dist / r));
                    e.takeKnockback(1.3, this.getX() - e.getX(), this.getZ() - e.getZ());
                    e.velocityModified = true;
                }
            }
            ring(world, YELLOW_BIG, center, r * 0.35, 20);
            ring(world, YELLOW_BIG, center, r * 0.7, 28);
            ring(world, YELLOW_BIG, center, r, 36);
            sfx(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 1.3f);
        } else if (abilityTick >= charge + 10) {
            finishAbility();
        }
    }

    // ---- Ataque descendente: sube, marca el punto, se queda 12 ticks avisando y cae ----
    private void runDive(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        if (abilityTick < 20) {
            setCombatPose(POSE_RAISE);
            this.getMoveControl().moveTo(t.getX(), t.getY() + 8.0, t.getZ(), 1.4);
        } else if (abilityTick == 20) {
            lockedPos = t.getPos();
            this.setVelocity(Vec3d.ZERO);
        } else if (abilityTick < 32) {
            setCombatPose(POSE_RAISE);
            this.setVelocity(Vec3d.ZERO);
            if (abilityTick % 3 == 0) {
                ring(world, TELEGRAPH, lockedPos.add(0, 0.1, 0), cfg.diveRadius, 28);
            }
        } else {
            setCombatPose(POSE_PLUNGE);
            Vec3d to = lockedPos.add(0, 1.0, 0).subtract(this.getPos());
            boolean landed = to.length() < 1.6
                    || (abilityTick > 34 && (this.verticalCollision || this.horizontalCollision))
                    || abilityTick > 70;
            if (landed) {
                diveSlam(world, cfg);
                this.setVelocity(Vec3d.ZERO);
                finishAbility();
            } else {
                this.setVelocity(to.normalize().multiply(1.5));
                dust(world, YELLOW, this.getX(), this.getY() + 1.0, this.getZ(), 4, 0.3, 0.5, 0.3);
            }
        }
    }

    private void diveSlam(ServerWorld world, SinestroConfig cfg) {
        double r = cfg.diveRadius;
        Vec3d c = this.getPos();
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(r, 3.0, r),
                this::isValidVictim)) {
            double hd = Math.hypot(e.getX() - c.x, e.getZ() - c.z);
            if (hd <= r && Math.abs(e.getY() - c.y) < 3.5) {
                hurt(e, cfg.diveDamage * (1.0 - 0.5 * hd / r));
                e.takeKnockback(1.2, c.x - e.getX(), c.z - e.getZ());
                e.velocityModified = true;
            }
        }
        ring(world, YELLOW_BIG, c.add(0, 0.2, 0), r * 0.5, 24);
        ring(world, YELLOW_BIG, c.add(0, 0.2, 0), r, 36);
        sfx(SoundEvents.ENTITY_GENERIC_EXPLODE, 2.0f, 1.2f);
    }

    // ---- Impulso aéreo: 8 ticks de velocidad alta para reposicionarse ----
    private void chooseDashDirection(LivingEntity t) {
        Vec3d toTarget = t.getPos().subtract(this.getPos());
        Vec3d flat = new Vec3d(toTarget.x, 0, toTarget.z);
        flat = flat.lengthSquared() > 1.0E-4 ? flat.normalize() : new Vec3d(0, 0, 1);
        Vec3d dir;
        if (toTarget.length() > 14.0) {
            double side = this.random.nextBoolean() ? 1.0 : -1.0;
            Vec3d perp = new Vec3d(-flat.z * side, 0, flat.x * side);
            Vec3d dest = t.getPos().add(perp.multiply(5.0)).add(0, 2.5, 0);
            dir = dest.subtract(this.getPos());
        } else {
            dir = new Vec3d(-flat.x, 0.3, -flat.z); // se aleja de un jugador pegado a él
        }
        dir = dir.lengthSquared() > 1.0E-4 ? dir.normalize() : new Vec3d(0, 1, 0);
        if (pathBlocked(this.getEyePos(), this.getEyePos().add(dir.multiply(8.0)))) {
            dir = new Vec3d(dir.x, 0.8, dir.z).normalize();
        }
        dashDir = dir;
    }

    private void runDash(ServerWorld world) {
        setCombatPose(POSE_PLUNGE);
        if (abilityTick <= 8) {
            this.setVelocity(dashDir.multiply(0.95));
            dust(world, YELLOW, this.getX(), this.getY() + 1.0, this.getZ(), 4, 0.3, 0.5, 0.3);
        } else {
            this.setVelocity(this.getVelocity().multiply(0.4));
            finishAbility();
        }
    }

    // ---- Puño gigante de energía: zona de aviso, columna que desciende, impacto ----
    private void runFist(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        int tele = cfg.fistTelegraphTicks;
        if (abilityTick < 8) {
            setCombatPose(POSE_RAISE);
            lockedPos = t.getPos();
        } else if (abilityTick < 8 + tele) {
            setCombatPose(POSE_RAISE);
            if (abilityTick % 3 == 0) {
                double progress = (double) (abilityTick - 8) / tele;
                ring(world, TELEGRAPH, lockedPos.add(0, 0.1, 0), cfg.fistRadius, 24);
                double y = lockedPos.y + 8.0 * (1.0 - progress);
                dust(world, GOLD, lockedPos.x, y, lockedPos.z, 10, 0.7, 0.7, 0.7);
            }
        } else if (abilityTick == 8 + tele) {
            setCombatPose(POSE_SLAM);
            double r = cfg.fistRadius;
            for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class,
                    new Box(lockedPos, lockedPos).expand(r + 1.0, 4.0, r + 1.0), this::isValidVictim)) {
                double hd = Math.hypot(e.getX() - lockedPos.x, e.getZ() - lockedPos.z);
                if (hd <= r && Math.abs(e.getY() - lockedPos.y) < 3.5) {
                    hurt(e, cfg.fistDamage);
                    e.addVelocity(0, 0.7, 0);
                    e.velocityModified = true;
                }
            }
            dust(world, YELLOW_BIG, lockedPos.x, lockedPos.y + 1.0, lockedPos.z, 40, 0.8, 0.8, 0.8);
            ring(world, YELLOW_BIG, lockedPos.add(0, 0.2, 0), r, 28);
            sfx(SoundEvents.BLOCK_ANVIL_LAND, 2.0f, 0.6f);
        } else if (abilityTick >= 8 + tele + 10) {
            finishAbility();
        }
    }

    // ---- Jaula: se cierra alrededor del objetivo durante un tiempo limitado ----
    private void runCage(ServerWorld world, SinestroConfig cfg, LivingEntity t) {
        if (abilityTick < 15) {
            setCombatPose(POSE_RAISE);
            double radius = cfg.cageRadius * 2.0 * (1.0 - (double) abilityTick / 15.0) + cfg.cageRadius;
            if (abilityTick % 3 == 0) {
                ring(world, TELEGRAPH, t.getPos().add(0, 0.1, 0), radius, 20);
            }
        } else if (abilityTick == 15) {
            setCombatPose(POSE_SLAM);
            cageTarget = t.getUuid();
            cageCenter = t.getPos();
            cageTicks = cfg.cageDuration;
            sfx(SoundEvents.BLOCK_CHAIN_PLACE, 2.0f, 0.7f);
        } else if (abilityTick >= 20) {
            finishAbility();
        }
    }

    private void tickCage(ServerWorld world, SinestroConfig cfg) {
        if (cageTicks <= 0) {
            return;
        }
        cageTicks--;
        Entity e = cageTarget == null ? null : world.getEntity(cageTarget);
        if (!(e instanceof LivingEntity victim) || !victim.isAlive() || transitionTicks > 0) {
            endCage(world);
            return;
        }
        double r = cfg.cageRadius;
        double dx = victim.getX() - cageCenter.x;
        double dz = victim.getZ() - cageCenter.z;
        double hd = Math.hypot(dx, dz);
        if (hd > r - 0.35 && hd > 1.0E-3) {
            victim.setVelocity(-dx / hd * 0.5, victim.getVelocity().y, -dz / hd * 0.5);
            victim.velocityModified = true;
            if (hd > r + 1.0) {
                victim.requestTeleport(cageCenter.x + dx / hd * (r - 0.5), victim.getY(), cageCenter.z + dz / hd * (r - 0.5));
            }
        }
        if (victim.getY() > cageCenter.y + 3.5) {
            Vec3d v = victim.getVelocity();
            victim.setVelocity(v.x, Math.min(v.y, -0.15), v.z);
            victim.velocityModified = true;
        }
        if (cageTicks % 4 == 0) {
            int bars = 10;
            for (int i = 0; i < bars; i++) {
                double a = 2.0 * Math.PI * i / bars;
                double bx = cageCenter.x + Math.cos(a) * r;
                double bz = cageCenter.z + Math.sin(a) * r;
                for (int h = 0; h < 4; h++) {
                    world.spawnParticles(YELLOW, bx, cageCenter.y + 0.2 + h * 1.0, bz, 1, 0, 0, 0, 0);
                }
            }
        }
        if (cageTicks == 0) {
            endCage(world);
        }
    }

    private void endCage(ServerWorld world) {
        if (cageTicks > 0 || cageTarget != null) {
            ring(world, YELLOW_BIG, cageCenter.add(0, 1.0, 0), cfgCageRadius(), 20); // efecto de desaparición
        }
        cageTicks = 0;
        cageTarget = null;
    }

    private double cfgCageRadius() {
        return SinestroConfig.get().cageRadius;
    }

    // =====================================================================
    //  Escudo, contraataque, aura de miedo, soldados
    // =====================================================================
    private void tickShield(ServerWorld world, SinestroConfig cfg) {
        if (shieldTicks > 0) {
            shieldTicks--;
            if (shieldTicks % 3 == 0) {
                ring(world, YELLOW, this.getPos().add(0, 0.3, 0), 1.3, 12);
                ring(world, YELLOW, this.getPos().add(0, 1.0, 0), 1.6, 12);
                ring(world, YELLOW, this.getPos().add(0, 1.8, 0), 1.2, 12);
            }
        } else if (recentDamage >= cfg.shieldTriggerDamage && shieldCooldown <= 0 && transitionTicks <= 0) {
            shieldTicks = cfg.shieldDuration;
            shieldCooldown = cfg.shieldCooldown;
            recentDamage = 0.0f;
            sfx(SoundEvents.ITEM_SHIELD_BLOCK, 2.0f, 0.8f);
            voice(ModSounds.VOICE_SPECIAL, cfg.voiceSpecialChance);
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.getWorld().isClient || !(this.getWorld() instanceof ServerWorld world)) {
            return super.damage(source, amount);
        }
        SinestroConfig cfg = SinestroConfig.get();
        if (shieldTicks > 0 && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount = (float) (amount * (1.0 - cfg.shieldReduction));
            dust(world, YELLOW_BIG, this.getX(), this.getY() + 1.0, this.getZ(), 8, 0.6, 0.9, 0.6);
            sfx(SoundEvents.ITEM_SHIELD_BLOCK, 1.0f, 1.0f);
        }
        boolean hit = super.damage(source, amount);
        if (hit) {
            recentDamage += amount;
            if (hurtVoiceCd <= 0) {
                voice(ModSounds.VOICE_HURT, cfg.voiceHurtChance);
                hurtVoiceCd = cfg.voiceHurtCooldown;
            }
            if (source.getAttacker() instanceof LivingEntity attacker && isValidVictim(attacker)) {
                tryCounter(world, cfg, attacker);
            }
        }
        return hit;
    }

    private void tryCounter(ServerWorld world, SinestroConfig cfg, LivingEntity attacker) {
        if (counterCooldown > 0 || transitionTicks > 0 || this.distanceTo(attacker) > 8.0f
                || this.random.nextDouble() >= cfg.counterChance) {
            return;
        }
        counterCooldown = cfg.counterCooldown;
        hurt(attacker, cfg.counterDamage);
        attacker.takeKnockback(1.0, this.getX() - attacker.getX(), this.getZ() - attacker.getZ());
        attacker.velocityModified = true;
        ring(world, YELLOW_BIG, this.getPos().add(0, 1.0, 0), 1.5, 20);
        sfx(SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, 1.5f, 1.2f);
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (transitionTicks > 0 && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return true; // durante la transición de fase no recibe daño
        }
        return super.isInvulnerableTo(source);
    }

    private void tickFear(ServerWorld world, SinestroConfig cfg) {
        if (!cfg.fearAura || phase < 3) {
            return;
        }
        if (auraCooldown > 0) {
            auraCooldown--;
            return;
        }
        auraCooldown = 100;
        dust(world, YELLOW_BIG, this.getX(), this.getY() + 1.0, this.getZ(), 30, 3.0, 1.2, 3.0);
        for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(10.0),
                this::isValidVictim)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 30, 0));
        }
    }

    private void summonMinions(ServerWorld world, LivingEntity target) {
        SinestroConfig cfg = SinestroConfig.get();
        minions.removeIf(v -> !v.isAlive());
        for (int i = 0; i < 2 && minions.size() < cfg.maxMinions; i++) {
            VexEntity vex = EntityType.VEX.create(world);
            if (vex == null) {
                continue;
            }
            vex.refreshPositionAndAngles(
                    this.getX() + (this.random.nextDouble() - 0.5) * 3.0,
                    this.getY() + 0.5,
                    this.getZ() + (this.random.nextDouble() - 0.5) * 3.0,
                    this.random.nextFloat() * 360.0f, 0.0f);
            vex.initialize(world, world.getLocalDifficulty(vex.getBlockPos()), SpawnReason.MOB_SUMMONED, null, null);
            vex.setOwner(this);
            vex.setLifeTicks(20 * 40);
            vex.setTarget(target);
            world.spawnEntity(vex);
            minions.add(vex);
        }
        sfx(SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, 1.5f, 0.8f);
    }

    // =====================================================================
    //  Atascos y ambiente
    // =====================================================================
    private void tickStuck(LivingEntity target) {
        if (unstuckTicks > 0) {
            unstuckTicks--;
        }
        if (isMovementLocked()) {
            stuckTicks = 0;
            stuckAnchor = this.getPos();
            return;
        }
        if (++stuckTicks >= 40) {
            if (this.getPos().distanceTo(stuckAnchor) < 0.6 && this.distanceTo(target) > 6.0f) {
                unstuckTicks = 30;
            }
            stuckAnchor = this.getPos();
            stuckTicks = 0;
        }
    }

    private void tickAmbient(ServerWorld world) {
        if (this.age % 6 == 0) {
            dust(world, YELLOW, this.getX(), this.getY() + 1.0, this.getZ(), phase * 2, 0.5, 0.8, 0.5);
            if (phase >= 3) {
                dust(world, GOLD, this.getX(), this.getY() + 1.0, this.getZ(), 3, 0.6, 0.9, 0.6);
            }
        }
    }

    private void tickIdleVoice(SinestroConfig cfg) {
        if (current == null && this.age % 40 == 0 && idleVoiceCd <= 0) {
            idleVoiceCd = cfg.voiceIdleCooldown;
            voice(ModSounds.VOICE_IDLE, cfg.voiceIdleChance);
        }
    }

    // =====================================================================
    //  Utilidades: daño, rayos exactos, partículas, sonido, voces
    // =====================================================================
    private boolean isValidVictim(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof SinestroEntity || minions.contains(e)) {
            return false;
        }
        return !(e instanceof PlayerEntity p && (p.isCreative() || p.isSpectator()));
    }

    private void hurt(LivingEntity victim, double amount) {
        victim.damage(this.getDamageSources().indirectMagic(this, this), (float) amount);
    }

    private Vec3d aimAt(LivingEntity target) {
        Vec3d from = this.getEyePos();
        Vec3d to = new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ());
        Vec3d dir = to.subtract(from);
        return dir.lengthSquared() > 1.0E-4 ? dir.normalize() : new Vec3d(0, 0, 1);
    }

    private void fireBolt(ServerWorld world, Vec3d dir, double damage, double radius) {
        Vec3d from = this.getEyePos().add(0, -0.3, 0);
        for (LivingEntity e : traceEntities(world, from, dir, 40.0, radius, YELLOW)) {
            hurt(e, damage);
        }
        sfx(SoundEvents.ENTITY_BLAZE_SHOOT, 1.0f, 1.4f);
    }

    /**
     * Traza un rayo que se detiene en el primer bloque sólido (nada atraviesa paredes) y devuelve
     * solo las entidades realmente tocadas por la línea. Dibuja partículas si fx != null.
     */
    private List<LivingEntity> traceEntities(ServerWorld world, Vec3d from, Vec3d dir, double range,
                                             double radius, DustParticleEffect fx) {
        Vec3d end = from.add(dir.multiply(range));
        BlockHitResult hit = world.raycast(new RaycastContext(from, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, this));
        double len = hit.getType() == HitResult.Type.MISS ? range : from.distanceTo(hit.getPos());
        Vec3d realEnd = from.add(dir.multiply(len));

        if (fx != null) {
            double step = 0.8 / Math.max(0.25, SinestroConfig.get().particleMultiplier);
            for (double d = 1.0; d < len; d += step) {
                Vec3d p = from.add(dir.multiply(d));
                world.spawnParticles(fx, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.0);
            }
        }
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class,
                new Box(from, realEnd).expand(radius + 2.0), this::isValidVictim)) {
            Vec3d c = e.getBoundingBox().getCenter();
            double t = MathHelper.clamp(c.subtract(from).dotProduct(dir), 0.0, len);
            Vec3d closest = from.add(dir.multiply(t));
            if (closest.distanceTo(c) <= radius + e.getWidth() * 0.5 + 0.2) {
                out.add(e);
            }
        }
        return out;
    }

    private static int scaled(int n) {
        return Math.max(1, (int) Math.round(n * SinestroConfig.get().particleMultiplier));
    }

    private void dust(ServerWorld world, DustParticleEffect fx, double x, double y, double z, int count,
                      double dx, double dy, double dz) {
        world.spawnParticles(fx, x, y, z, scaled(count), dx, dy, dz, 0.0);
    }

    private void ring(ServerWorld world, DustParticleEffect fx, Vec3d c, double radius, int points) {
        int n = Math.max(6, scaled(points));
        for (int i = 0; i < n; i++) {
            double a = 2.0 * Math.PI * i / n;
            world.spawnParticles(fx, c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius, 1, 0, 0, 0, 0.0);
        }
    }

    /** Efecto de sonido con separación mínima para que no se superpongan. */
    private void sfx(SoundEvent sound, float volume, float pitch) {
        if (this.age - lastSfxAge < 3) {
            return;
        }
        lastSfxAge = this.age;
        this.getWorld().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundCategory.HOSTILE, volume, pitch);
    }

    /** Voz con probabilidad y un tiempo mínimo entre voces. */
    private void voice(SoundEvent sound, double chance) {
        if (voiceGlobalCd > 0 || this.random.nextDouble() >= chance) {
            return;
        }
        voiceForce(sound);
    }

    private void voiceForce(SoundEvent sound) {
        voiceGlobalCd = SinestroConfig.get().voiceGlobalCooldown;
        this.getWorld().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundCategory.HOSTILE, 2.5f, 1.0f);
    }

    /** Pequeña explosión de partículas amarillas (la usa el ataque cuerpo a cuerpo). */
    public void yellowBurst(double x, double y, double z, int count) {
        if (this.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(YELLOW, x, y, z, scaled(count), 0.4, 0.4, 0.4, 0.05);
        }
    }

    // =====================================================================
    //  Muerte, barra de jefe, NBT
    // =====================================================================
    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        if (this.getWorld() instanceof ServerWorld world) {
            endCage(world);
            voiceForce(ModSounds.VOICE_DEATH);
        }
        cancelAbility();
        shieldTicks = 0;
        transitionTicks = 0;
        for (VexEntity vex : minions) {
            vex.discard();
        }
        minions.clear();
        this.setNoGravity(false);
    }

    @Override
    protected void updatePostDeath() {
        this.deathTime++;
        if (this.getWorld() instanceof ServerWorld world) {
            dust(world, GOLD, this.getX(), this.getY() + 1.0, this.getZ(), 12, 0.6, 1.0, 0.6);
            if (this.deathTime % 10 == 0) {
                ring(world, YELLOW_BIG, this.getPos().add(0, 1.0, 0), this.deathTime * 0.2, 20);
            }
            if (this.deathTime >= 40 && !this.isRemoved()) {
                world.sendEntityStatus(this, (byte) 60);
                this.remove(Entity.RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        this.bossBar.setName(this.getDisplayName());
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("SinestroPhase", phase);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("SinestroPhase")) {
            phase = MathHelper.clamp(nbt.getInt("SinestroPhase"), 1, 3);
        }
        if (this.hasCustomName()) {
            this.bossBar.setName(this.getDisplayName());
        }
        enraged = false; // los modificadores temporales no se guardan; se reaplican solos en fase 3
        applyPhaseBar();
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ----- Sonidos básicos (las voces propias se reproducen con ModSounds) -----
    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_EVOKER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return null;
    }
}
