package com.sinestroboss.entity;

import java.util.EnumSet;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Movimiento en vuelo: elige un destino cada ~0,6 s (sin vibrar), mantiene distancia según la fase,
 * rodea obstáculos subiendo y se aparta si detecta que está atascado.
 * Mientras una habilidad controla el movimiento (isMovementLocked) esta meta espera.
 */
public class SinestroCombatGoal extends Goal {
    private final SinestroEntity boss;
    private int meleeCooldown = 0;
    private int repathTicks = 0;
    private int strafeDir = 1;
    private Vec3d dest = null;

    public SinestroCombatGoal(SinestroEntity boss) {
        this.boss = boss;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
    }

    @Override
    public boolean canStart() {
        LivingEntity target = boss.getTarget();
        return target != null && target.isAlive();
    }

    @Override
    public boolean shouldContinue() {
        return canStart();
    }

    @Override
    public void start() {
        repathTicks = 0;
        dest = null;
    }

    @Override
    public void tick() {
        LivingEntity target = boss.getTarget();
        if (target == null) {
            return;
        }
        boss.getLookControl().lookAt(target, 30.0f, 30.0f);

        double dist = boss.distanceTo(target);
        if (meleeCooldown > 0) {
            meleeCooldown--;
        }
        if (dist <= 3.2 && meleeCooldown <= 0 && !boss.isTransitioning()) {
            boss.swingHand(Hand.MAIN_HAND);
            boss.tryAttack(target);
            boss.yellowBurst(target.getX(), target.getBodyY(0.5), target.getZ(), 12);
            meleeCooldown = 20;
        }

        if (boss.isMovementLocked()) {
            return;
        }
        if (boss.getUnstuckTicks() > 0) {
            boss.getMoveControl().moveTo(boss.getX() + (boss.getRandom().nextDouble() - 0.5) * 4.0,
                    boss.getY() + 4.0, boss.getZ() + (boss.getRandom().nextDouble() - 0.5) * 4.0, 1.2);
            dest = null;
            return;
        }
        if (--repathTicks <= 0 || dest == null || boss.squaredDistanceTo(dest) < 1.5) {
            dest = computeDestination(target, dist);
            repathTicks = 12 + boss.getRandom().nextInt(8);
        }
        boss.getMoveControl().moveTo(dest.x, dest.y, dest.z, boss.getPhase() >= 3 ? 1.3 : 1.0);
    }

    private Vec3d computeDestination(LivingEntity target, double dist) {
        int phase = boss.getPhase();
        Vec3d tp = target.getPos();
        Vec3d bp = boss.getPos();
        double desired = phase == 1 ? 9.0 : (phase == 2 ? 8.0 : 4.0);
        double hover = phase >= 3 ? 0.5 : 2.5 + boss.getRandom().nextDouble() * 1.5;

        Vec3d flat = new Vec3d(tp.x - bp.x, 0, tp.z - bp.z);
        flat = flat.lengthSquared() > 1.0E-4 ? flat.normalize() : new Vec3d(0, 0, 1);

        double x;
        double z;
        if (phase >= 3 && dist > 2.0) {
            x = tp.x;
            z = tp.z;
        } else if (dist > desired + 2.0) {
            x = tp.x - flat.x * desired;
            z = tp.z - flat.z * desired;
        } else if (dist < desired - 2.0 && phase < 3) {
            x = bp.x - flat.x * 5.0;
            z = bp.z - flat.z * 5.0;
        } else {
            if (boss.getRandom().nextInt(3) == 0) {
                strafeDir = -strafeDir;
            }
            x = bp.x + (-flat.z * strafeDir) * 5.0;
            z = bp.z + (flat.x * strafeDir) * 5.0;
        }
        Vec3d result = new Vec3d(x, tp.y + hover, z);

        // Evitar chocar con paredes/techos: si el camino está bloqueado, sube; si sigue, sube en el sitio.
        Vec3d eye = boss.getEyePos();
        if (boss.pathBlocked(eye, result.add(0, 1.0, 0))) {
            result = result.add(0, 4.0, 0);
            if (boss.pathBlocked(eye, result)) {
                result = new Vec3d(bp.x, bp.y + 4.0, bp.z);
            }
        }
        return result;
    }
}
