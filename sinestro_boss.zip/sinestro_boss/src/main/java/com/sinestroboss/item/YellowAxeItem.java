package com.sinestroboss.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import org.joml.Vector3f;

/** Hacha de energía amarilla: 9 de daño, velocidad 0.8 (más lenta que la espada). */
public class YellowAxeItem extends AxeItem {
    private static final DustParticleEffect FX = new DustParticleEffect(new Vector3f(1.0f, 0.65f, 0.0f), 1.6f);

    public YellowAxeItem(Settings settings) {
        super(YellowToolMaterial.INSTANCE, 5.0f, -3.2f, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (target.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(FX, target.getX(), target.getBodyY(0.5), target.getZ(), 16, 0.4, 0.4, 0.4, 0.06);
        }
        return result;
    }
}
