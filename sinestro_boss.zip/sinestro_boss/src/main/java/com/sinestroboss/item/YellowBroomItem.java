package com.sinestroboss.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

/**
 * Escoba de energía amarilla: 5 de daño, velocidad 2.0.
 * Habilidad: clic derecho = impulso de energía en la dirección en que miras (5 s de espera).
 */
public class YellowBroomItem extends SwordItem {
    private static final DustParticleEffect FX = new DustParticleEffect(new Vector3f(1.0f, 0.9f, 0.1f), 1.5f);
    private static final int DASH_COOLDOWN = 100;

    public YellowBroomItem(Settings settings) {
        super(YellowToolMaterial.INSTANCE, 1, -2.0f, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (target.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(FX, target.getX(), target.getBodyY(0.5), target.getZ(), 8, 0.3, 0.3, 0.3, 0.04);
        }
        return result;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        if (!world.isClient && world instanceof ServerWorld serverWorld) {
            Vec3d look = user.getRotationVec(1.0f);
            user.setVelocity(look.multiply(1.4));
            user.velocityModified = true;
            user.fallDistance = 0.0f;
            serverWorld.spawnParticles(FX, user.getX(), user.getY() + 0.8, user.getZ(), 20, 0.4, 0.4, 0.4, 0.05);
            serverWorld.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PHANTOM_SWOOP,
                    SoundCategory.PLAYERS, 1.0f, 1.3f);
        }
        user.getItemCooldownManager().set(this, DASH_COOLDOWN);
        return TypedActionResult.success(stack, world.isClient());
    }
}
