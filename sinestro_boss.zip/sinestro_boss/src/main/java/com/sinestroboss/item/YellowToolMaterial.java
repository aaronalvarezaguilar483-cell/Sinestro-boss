package com.sinestroboss.item;

import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class YellowToolMaterial implements ToolMaterial {
    public static final YellowToolMaterial INSTANCE = new YellowToolMaterial();

    @Override public int getDurability() { return 900; }
    @Override public float getMiningSpeedMultiplier() { return 7.0f; }
    @Override public float getAttackDamage() { return 3.0f; }
    @Override public int getMiningLevel() { return 3; }
    @Override public int getEnchantability() { return 20; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.GOLD_INGOT); }
}
