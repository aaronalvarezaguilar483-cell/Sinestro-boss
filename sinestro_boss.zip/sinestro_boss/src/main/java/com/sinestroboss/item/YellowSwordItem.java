package com.sinestroboss.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import org.joml.Vector3f;

/** Espada de energía amarilla: 7 de daño, velocidad 1.6. */
public class YellowSwordItem extends SwordItem {
    private static final DustParticleEffect FX = new DustParticleEffect(new Vector3f(1.0f, 0.85f, 0.05f), 1.2f);

    public YellowSwordItem(Settings settings) {
        super(YellowToolMaterial.INSTANCE, 3, -2.4f, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (target.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(FX, target.getX(), target.getBodyY(0.5), target.getZ(), 10, 0.3, 0.3, 0.3, 0.05);
        }
        return result;
    }
}
