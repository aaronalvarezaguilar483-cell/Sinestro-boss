package com.sinestroboss;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * Eventos de voz de Sinestro. Los audios (.ogg) los pones tú en
 * assets/sinestro_boss/sounds/voice/ (ver VOCES.md).
 */
public class ModSounds {
    public static final SoundEvent VOICE_IDLE = register("voice.idle");
    public static final SoundEvent VOICE_ATTACK = register("voice.attack");
    public static final SoundEvent VOICE_SPECIAL = register("voice.special");
    public static final SoundEvent VOICE_HURT = register("voice.hurt");
    public static final SoundEvent VOICE_PHASE = register("voice.phase");
    public static final SoundEvent VOICE_DEATH = register("voice.death");

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(SinestroBoss.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Carga la clase y registra los eventos.
    }
}
