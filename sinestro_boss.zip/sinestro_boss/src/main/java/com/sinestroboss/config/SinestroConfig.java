package com.sinestroboss.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sinestroboss.SinestroBoss;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Configuración en config/sinestro_boss.json. Se crea sola con valores por defecto
 * y los valores inválidos se corrigen al cargar. Tiempos en ticks (20 ticks = 1 segundo).
 */
public class SinestroConfig {
    // --- jefe ---
    public double maxHealth = 400.0;
    public double meleeDamage = 10.0;
    public double phase2Threshold = 0.60;
    public double phase3Threshold = 0.25;

    // --- proyectil y ráfaga ---
    public double boltDamage = 8.0;
    public int boltCooldown = 30;
    public int volleyShots = 4;
    public double volleyDamage = 5.0;
    public int volleyCooldown = 200;

    // --- rayo ---
    public double beamDamage = 5.0;
    public int beamChargeTicks = 30;
    public int beamFireTicks = 20;
    public int beamCooldown = 260;
    public double beamRange = 28.0;

    // --- nova ---
    public double novaDamage = 14.0;
    public double novaRadius = 8.0;
    public int novaChargeTicks = 45;
    public int novaCooldown = 400;

    // --- ataque descendente, impulso, puño ---
    public double diveDamage = 14.0;
    public double diveRadius = 5.0;
    public int diveCooldown = 360;
    public int dashCooldown = 160;
    public double fistDamage = 16.0;
    public double fistRadius = 2.5;
    public int fistTelegraphTicks = 30;
    public int fistCooldown = 300;

    // --- jaula ---
    public int cageDuration = 60;
    public double cageRadius = 2.0;
    public int cageCooldown = 700;

    // --- escudo y contraataque ---
    public int shieldDuration = 60;
    public int shieldCooldown = 500;
    public double shieldReduction = 0.7;
    public double shieldTriggerDamage = 40.0;
    public double counterChance = 0.25;
    public double counterDamage = 6.0;
    public int counterCooldown = 200;

    // --- ritmo del combate ---
    public int globalCooldownMin = 25;
    public int globalCooldownMax = 50;
    public int maxMinions = 4;
    public int minionCooldown = 300;
    public boolean fearAura = true;

    // --- partículas (1.0 = normal; baja el valor en celulares lentos) ---
    public double particleMultiplier = 1.0;

    // --- voces (probabilidades 0.0 a 1.0, tiempos en ticks) ---
    public double voiceIdleChance = 0.5;
    public int voiceIdleCooldown = 600;
    public double voiceAttackChance = 0.5;
    public double voiceSpecialChance = 0.8;
    public double voiceHurtChance = 0.25;
    public int voiceHurtCooldown = 100;
    public int voiceGlobalCooldown = 40;

    private static SinestroConfig instance = new SinestroConfig();

    public static SinestroConfig get() {
        return instance;
    }

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("sinestro_boss.json");
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        SinestroConfig loaded = null;
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path)) {
                loaded = gson.fromJson(reader, SinestroConfig.class);
            } catch (Exception e) {
                SinestroBoss.LOGGER.warn("No se pudo leer sinestro_boss.json, se usan los valores por defecto", e);
            }
        }
        if (loaded == null) {
            loaded = new SinestroConfig();
        }
        loaded.sanitize();
        instance = loaded;
        try (Writer writer = Files.newBufferedWriter(path)) {
            gson.toJson(loaded, writer);
        } catch (IOException e) {
            SinestroBoss.LOGGER.warn("No se pudo guardar sinestro_boss.json", e);
        }
    }

    private static double d(double v, double min, double max, double fallback) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return fallback;
        }
        return Math.max(min, Math.min(max, v));
    }

    private static int i(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private void sanitize() {
        maxHealth = d(maxHealth, 20, 100000, 400);
        meleeDamage = d(meleeDamage, 0, 1000, 10);
        phase2Threshold = d(phase2Threshold, 0.05, 0.95, 0.60);
        phase3Threshold = d(phase3Threshold, 0.02, 0.90, 0.25);
        if (phase3Threshold >= phase2Threshold) {
            phase2Threshold = 0.60;
            phase3Threshold = 0.25;
        }
        boltDamage = d(boltDamage, 0, 1000, 8);
        boltCooldown = i(boltCooldown, 5, 2400);
        volleyShots = i(volleyShots, 1, 10);
        volleyDamage = d(volleyDamage, 0, 1000, 5);
        volleyCooldown = i(volleyCooldown, 20, 6000);
        beamDamage = d(beamDamage, 0, 1000, 5);
        beamChargeTicks = i(beamChargeTicks, 15, 200);
        beamFireTicks = i(beamFireTicks, 4, 200);
        beamCooldown = i(beamCooldown, 40, 6000);
        beamRange = d(beamRange, 5, 64, 28);
        novaDamage = d(novaDamage, 0, 1000, 14);
        novaRadius = d(novaRadius, 2, 20, 8);
        novaChargeTicks = i(novaChargeTicks, 20, 200);
        novaCooldown = i(novaCooldown, 60, 6000);
        diveDamage = d(diveDamage, 0, 1000, 14);
        diveRadius = d(diveRadius, 1, 15, 5);
        diveCooldown = i(diveCooldown, 60, 6000);
        dashCooldown = i(dashCooldown, 20, 6000);
        fistDamage = d(fistDamage, 0, 1000, 16);
        fistRadius = d(fistRadius, 1, 8, 2.5);
        fistTelegraphTicks = i(fistTelegraphTicks, 15, 120);
        fistCooldown = i(fistCooldown, 60, 6000);
        cageDuration = i(cageDuration, 10, 100);
        cageRadius = d(cageRadius, 1, 5, 2.0);
        cageCooldown = i(cageCooldown, 200, 12000);
        shieldDuration = i(shieldDuration, 10, 200);
        shieldCooldown = i(shieldCooldown, 100, 12000);
        shieldReduction = d(shieldReduction, 0.0, 0.9, 0.7);
        shieldTriggerDamage = d(shieldTriggerDamage, 5, 1000, 40);
        counterChance = d(counterChance, 0.0, 1.0, 0.25);
        counterDamage = d(counterDamage, 0, 1000, 6);
        counterCooldown = i(counterCooldown, 20, 6000);
        globalCooldownMin = i(globalCooldownMin, 5, 400);
        globalCooldownMax = i(globalCooldownMax, globalCooldownMin, 600);
        maxMinions = i(maxMinions, 0, 8);
        minionCooldown = i(minionCooldown, 100, 6000);
        particleMultiplier = d(particleMultiplier, 0.1, 3.0, 1.0);
        voiceIdleChance = d(voiceIdleChance, 0.0, 1.0, 0.5);
        voiceIdleCooldown = i(voiceIdleCooldown, 100, 24000);
        voiceAttackChance = d(voiceAttackChance, 0.0, 1.0, 0.5);
        voiceSpecialChance = d(voiceSpecialChance, 0.0, 1.0, 0.8);
        voiceHurtChance = d(voiceHurtChance, 0.0, 1.0, 0.25);
        voiceHurtCooldown = i(voiceHurtCooldown, 20, 2400);
        voiceGlobalCooldown = i(voiceGlobalCooldown, 10, 1200);
    }
}
