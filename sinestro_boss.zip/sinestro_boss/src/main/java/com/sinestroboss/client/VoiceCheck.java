package com.sinestroboss.client;

import com.sinestroboss.SinestroBoss;
import java.util.List;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

/** Al iniciar el cliente avisa en el log de qué audios de voz faltan (no es un error, solo un aviso). */
public final class VoiceCheck {
    private static final List<String> FILES = List.of("idle", "attack", "special", "hurt", "phase", "death");

    private VoiceCheck() {
    }

    public static void run(ResourceManager manager) {
        int missing = 0;
        for (String name : FILES) {
            Identifier id = new Identifier(SinestroBoss.MOD_ID, "sounds/voice/" + name + ".ogg");
            if (manager.getResource(id).isEmpty()) {
                missing++;
                SinestroBoss.LOGGER.warn("[Sinestro] Falta el audio de voz: assets/{}/sounds/voice/{}.ogg (el evento quedará en silencio)",
                        SinestroBoss.MOD_ID, name);
            }
        }
        if (missing == 0) {
            SinestroBoss.LOGGER.info("[Sinestro] Todos los audios de voz están presentes.");
        }
    }
}
