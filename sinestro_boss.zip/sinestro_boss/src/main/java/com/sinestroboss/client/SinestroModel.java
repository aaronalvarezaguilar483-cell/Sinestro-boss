package com.sinestroboss.client;

import com.sinestroboss.entity.SinestroEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo de jugador con poses de combate sincronizadas con la IA:
 * 1 = brazos arriba (cargando), 2 = brazos al frente (disparando), 3 = golpe hacia abajo,
 * 4 = picada/impulso (cuerpo en línea). Sin pose, al volar rápido va en postura heroica.
 */
public class SinestroModel extends PlayerEntityModel<SinestroEntity> {
    private static final float MAX_LEAN_RADIANS = 1.309f; // 75 grados, igual que el renderer

    public SinestroModel(ModelPart root) {
        super(root, false);
    }

    @Override
    public void setAngles(SinestroEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        float lean = MathHelper.clamp(entity.getLean(), 0.0f, 1.0f);
        float bodyLean = lean * MAX_LEAN_RADIANS;
        int pose = entity.getCombatPose();

        switch (pose) {
            case SinestroEntity.POSE_RAISE -> {
                float p = -(2.7f + bodyLean * 0.8f);
                this.rightArm.pitch = p;
                this.leftArm.pitch = p;
                this.rightArm.roll = 0.3f;
                this.leftArm.roll = -0.3f;
            }
            case SinestroEntity.POSE_POINT -> {
                float p = -(1.5708f + bodyLean);
                this.rightArm.pitch = p;
                this.leftArm.pitch = p;
                this.rightArm.yaw = 0.0f;
                this.leftArm.yaw = 0.0f;
            }
            case SinestroEntity.POSE_SLAM -> {
                float p = -(0.9f + bodyLean * 0.5f);
                this.rightArm.pitch = p;
                this.leftArm.pitch = p;
            }
            default -> {
                if (lean > 0.01f) {
                    float up = -(float) Math.PI; // brazos estirados en el eje del cuerpo
                    this.rightArm.pitch = MathHelper.lerp(lean, this.rightArm.pitch, up);
                    this.leftArm.pitch = MathHelper.lerp(lean, this.leftArm.pitch, up);
                }
            }
        }

        if (lean > 0.01f) {
            this.rightLeg.pitch *= (1.0f - lean);
            this.leftLeg.pitch *= (1.0f - lean);
            this.head.pitch -= lean * 1.2f; // mira al frente aunque el cuerpo esté inclinado
        }

        // PlayerEntityModel ya copió estas capas; se vuelven a copiar tras tocar las partes.
        this.hat.copyTransform(this.head);
        this.leftSleeve.copyTransform(this.leftArm);
        this.rightSleeve.copyTransform(this.rightArm);
        this.leftPants.copyTransform(this.leftLeg);
        this.rightPants.copyTransform(this.rightLeg);
    }
}
