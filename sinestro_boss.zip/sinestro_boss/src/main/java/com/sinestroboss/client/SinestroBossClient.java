package com.sinestroboss.client;

import com.sinestroboss.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class SinestroBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.SINESTRO, SinestroRenderer::new);
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> VoiceCheck.run(client.getResourceManager()));
    }
}
