package com.sinestroboss;

import com.sinestroboss.config.SinestroConfig;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SinestroBoss implements ModInitializer {
    public static final String MOD_ID = "sinestro_boss";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        SinestroConfig.load();
        ModSounds.register();
        ModEntities.register();
        ModItems.register();
    }
}
