package com.sinestroboss.entity;

import java.util.EnumSet;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** Movimiento en vuelo: mantiene distancia en fases 1-2, ataca de cerca en fase 3. */
public class SinestroCombatGoal extends Goal {
    private final SinestroEntity boss;
    private int meleeCooldown = 0;
    private int strafeTicks = 0;
    private int strafeDir = 1;

    public SinestroCombatGoal(SinestroEntity boss) {
        this.boss = boss;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
    }

    @Override
    public boolean canStart() {
        LivingEntity target = boss.getTarget();
        return target != null && target.isAlive();
    }

    @Override
    public boolean shouldContinue() {
        return canStart();
    }

    @Override
    public void tick() {
        LivingEntity target = boss.getTarget();
        if (target == null) {
            return;
        }
        boss.getLookControl().lookAt(target, 30.0f, 30.0f);

        int phase = boss.getPhase();
        double dist = boss.distanceTo(target);
        double desired = phase >= 3 ? 2.6 : 9.0;
        // Si el jugador consigue alejarse, Sinestro entra en persecución aérea:
        // acelera y gana altura para que la pose de vuelo y el aura se noten.
        boolean chasingAtRange = dist > 12.0;
        double targetY = target.getY() + (chasingAtRange ? 3.5 : (phase >= 3 ? 1.0 : 3.0));

        Vec3d flat = new Vec3d(target.getX() - boss.getX(), 0, target.getZ() - boss.getZ());
        flat = flat.lengthSquared() > 1.0E-4 ? flat.normalize() : Vec3d.ZERO;

        if (--strafeTicks <= 0) {
            strafeDir = -strafeDir;
            strafeTicks = 40 + boss.getRandom().nextInt(40);
        }

        double destX;
        double destZ;
        if (dist > desired + 2.0) {
            destX = target.getX();
            destZ = target.getZ();
        } else if (dist < desired - 2.0 && phase < 3) {
            destX = boss.getX() - flat.x * 4.0;
            destZ = boss.getZ() - flat.z * 4.0;
        } else {
            destX = boss.getX() + (-flat.z * strafeDir) * 3.0;
            destZ = boss.getZ() + (flat.x * strafeDir) * 3.0;
        }
        double flightSpeed = chasingAtRange ? 1.25 : (phase >= 3 ? 1.15 : 0.85);
        boss.getMoveControl().moveTo(destX, targetY, destZ, flightSpeed);

        if (meleeCooldown > 0) {
            meleeCooldown--;
        }
        double horizontalDistSq = boss.squaredDistanceTo(target.getX(), boss.getY(), target.getZ());
        double verticalDist = Math.abs(target.getY() - boss.getY());
        if (horizontalDistSq <= 2.8 * 2.8 && verticalDist <= 2.5 && meleeCooldown <= 0) {
            boss.swingHand(Hand.MAIN_HAND);
            boss.tryAttack(target);
            boss.yellowBurst(target.getX(), target.getBodyY(0.5), target.getZ(), 20);
            boss.getWorld().playSound(null, boss.getBlockPos(),
                    net.minecraft.sound.SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                    net.minecraft.sound.SoundCategory.HOSTILE, 1.1f, 0.65f);
            meleeCooldown = 24;
        }
    }
}
