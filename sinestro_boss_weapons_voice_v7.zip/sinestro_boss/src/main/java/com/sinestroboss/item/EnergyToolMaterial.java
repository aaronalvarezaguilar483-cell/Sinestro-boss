package com.sinestroboss.item;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.item.Items;

public class EnergyToolMaterial implements ToolMaterial {
    public static final EnergyToolMaterial INSTANCE = new EnergyToolMaterial();
    private EnergyToolMaterial() {}
    @Override public int getDurability() { return 1800; }
    @Override public float getMiningSpeedMultiplier() { return 9.0f; }
    @Override public float getAttackDamage() { return 4.0f; }
    @Override public int getMiningLevel() { return 4; }
    @Override public int getEnchantability() { return 18; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.GOLD_INGOT); }
}
