package com.sinestroboss.client;

import com.sinestroboss.entity.SinestroEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo de jugador con pose de vuelo "heroico": al moverse rápido el cuerpo se inclina
 * (ver SinestroRenderer), los brazos van al frente y las piernas quedan quietas.
 */
public class SinestroModel extends PlayerEntityModel<SinestroEntity> {
    public SinestroModel(ModelPart root) {
        super(root, false);
    }

    @Override
    public void setAngles(SinestroEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        // Pose de vuelo estable: no usar limbDistance como ángulo corporal,
        // porque cambia bruscamente con la velocidad y causa brazos/piernas deformados.
        // El vuelo se calcula con la velocidad real, no con limbDistance (que suele
        // ser casi cero en entidades voladoras). Así la pose funciona también en el aire.
        float speed = MathHelper.clamp((float) entity.getVelocity().horizontalLength() * 2.4f, 0.0f, 1.0f);
        float flap = MathHelper.sin(animationProgress * 0.35f) * 0.08f;
        // No sobrescribir la animación de golpeo que acaba de aplicar super.setAngles().
        boolean swinging = entity.handSwinging;
        if (!swinging) {
            this.rightArm.pitch = MathHelper.lerp(speed, this.rightArm.pitch, -1.25f) + flap;
            this.leftArm.pitch = MathHelper.lerp(speed, this.leftArm.pitch, -1.25f) - flap;
            this.rightArm.roll = MathHelper.lerp(speed, this.rightArm.roll, 0.12f);
            this.leftArm.roll = MathHelper.lerp(speed, this.leftArm.roll, -0.12f);
        }
        this.rightLeg.pitch = MathHelper.lerp(speed, this.rightLeg.pitch, 0.18f);
        this.leftLeg.pitch = MathHelper.lerp(speed, this.leftLeg.pitch, -0.12f);

        // PlayerEntityModel ya copió estas capas; las volvemos a copiar tras tocar las partes.
        this.hat.copyTransform(this.head);
        this.leftSleeve.copyTransform(this.leftArm);
        this.rightSleeve.copyTransform(this.rightArm);
        this.leftPants.copyTransform(this.leftLeg);
        this.rightPants.copyTransform(this.rightLeg);
    }
}
