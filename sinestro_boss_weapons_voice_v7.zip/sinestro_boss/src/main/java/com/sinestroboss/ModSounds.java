package com.sinestroboss;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    public static final SoundEvent SINESTRO_VOICE_IDLE = register("sinestro_voice_idle");
    public static final SoundEvent SINESTRO_VOICE_ATTACK = register("sinestro_voice_attack");
    public static final SoundEvent SINESTRO_VOICE_HURT = register("sinestro_voice_hurt");

    private ModSounds() {}

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(SinestroBoss.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Las referencias estáticas registran los eventos de voz.
    }
}
