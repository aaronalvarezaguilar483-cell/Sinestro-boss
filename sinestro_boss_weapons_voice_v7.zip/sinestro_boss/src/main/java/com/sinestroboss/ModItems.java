package com.sinestroboss;

import com.sinestroboss.item.EnergyToolMaterial;
import com.sinestroboss.item.SummonItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SwordItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item FEAR_TOTEM = Registry.register(
            Registries.ITEM,
            new Identifier(SinestroBoss.MOD_ID, "fear_totem"),
            new SummonItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    public static final Item SINESTRO_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(SinestroBoss.MOD_ID, "sinestro_spawn_egg"),
            new SpawnEggItem(ModEntities.SINESTRO, 0xD4A41B, 0x171616, new Item.Settings()));

    public static final Item YELLOW_ENERGY_SWORD = Registry.register(
            Registries.ITEM, new Identifier(SinestroBoss.MOD_ID, "yellow_energy_sword"),
            new SwordItem(EnergyToolMaterial.INSTANCE, 7, -2.0f, new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    public static final Item YELLOW_ENERGY_AXE = Registry.register(
            Registries.ITEM, new Identifier(SinestroBoss.MOD_ID, "yellow_energy_axe"),
            new AxeItem(EnergyToolMaterial.INSTANCE, 9.0f, -3.0f, new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    public static final Item YELLOW_ENERGY_BROOM = Registry.register(
            Registries.ITEM, new Identifier(SinestroBoss.MOD_ID, "yellow_energy_broom"),
            new SwordItem(EnergyToolMaterial.INSTANCE, 5, -1.6f, new Item.Settings().maxCount(1).rarity(Rarity.RARE)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(SINESTRO_SPAWN_EGG));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(FEAR_TOTEM);
            entries.add(YELLOW_ENERGY_SWORD);
            entries.add(YELLOW_ENERGY_AXE);
            entries.add(YELLOW_ENERGY_BROOM);
        });
    }
}
