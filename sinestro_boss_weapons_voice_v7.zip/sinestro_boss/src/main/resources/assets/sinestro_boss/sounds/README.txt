VOZ PROPIA DE SINESTRO
Coloca aquí archivos de audio OGG mono, preferiblemente 22050 Hz:
- sinestro_voice_idle.ogg (frase de aparición/amenaza)
- sinestro_voice_attack.ogg (frase al usar ataques)
- sinestro_voice_hurt.ogg (frase al recibir daño)

Ruta de recursos esperada:
assets/sinestro_boss/sounds/sinestro_voice_idle.ogg
assets/sinestro_boss/sounds/sinestro_voice_attack.ogg
assets/sinestro_boss/sounds/sinestro_voice_hurt.ogg

No se incluyen voces copiadas de otros mods ni voces falsas de aldeanos. Los eventos están declarados para integrar grabaciones propias cuando estén disponibles.
