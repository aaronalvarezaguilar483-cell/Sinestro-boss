# Sinestro Boss (Fabric 1.20.1)

Jefe Sinestro para el addon A New Corps. Requiere: Fabric Loader, Fabric API y A New Corps (+ Palladium, GeckoLib, KubeJS, Trinkets que ese addon ya pide).

## Compilar sin PC (GitHub Actions)
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (incluida la carpeta oculta .github).
2. Ve a la pestaña Actions -> "build" -> Run workflow (o se ejecuta solo al subir).
3. Al terminar, abre la ejecución y descarga el artefacto "sinestro_boss": dentro está el .jar.
4. Pon el .jar (el que NO termina en -sources) en la carpeta mods.

## Cómo usarlo
- Huevo generador: pestaña de huevos del creativo.
- Tótem del Miedo: se craftea con 8 bloques de oro + 1 estrella del Nether; clic derecho en un bloque para invocar.
- No funciona en dificultad Pacífica (los mobs hostiles desaparecen).
\n\n## Ajustes de corrección\n- Los rayos ahora comprueban colisión con bloques y entidades en un alcance limitado.\n- El aura de fase 3 afecta solo a objetivos cercanos.\n- La pose de vuelo usa la velocidad real de la entidad.\n- La pose de vuelo no sobrescribe el movimiento del brazo durante el golpe.\n\n- Nueva aura visual amarilla envolvente durante el vuelo, inspirada en los efectos de energía de los Lanterns. El efecto es solo visual y no causa daño.\n
\n## Ataques y efectos v4
- Golpe cuerpo a cuerpo con animación de brazo, sonido y ráfaga de partículas al impactar.
- Disparo de energía amarilla con animación de brazo y partículas de trayectoria.
- Rayo cargado con aviso visual antes de dispararse y partículas de impacto.
- Nova amarilla de área en fase 3: anillos de partículas en 360 grados, sonido, daño y retroceso en radio corto.
- Invocación de soldados en fases 2 y 3 conservada.
\nNota: el proyecto debe compilarse y probarse en Minecraft antes de dar por confirmados los cambios.

\n## Persecución aérea y aura amarilla v5
- Si el jugador se aleja a más de 12 bloques, Sinestro entra en persecución aérea rápida y apunta a una posición algo más alta que el jugador.
- La pose de vuelo del modelo se basa en la velocidad real de la entidad.
- Mientras está en el aire o se mueve, aparece el aura amarilla de partículas envolventes.
- La aura es visual; no causa daño por sí misma.
\nPendiente: compilar con Gradle/GitHub Actions y probar en Minecraft 1.20.1. No se ha confirmado aún la compilación.

\n## Constructos de energía v6
- Sinestro crea una jaula geométrica temporal de energía amarilla alrededor del objetivo en fases 2 y 3, a distancia media.
- El constructo se representa con pilares, líneas, destello de aparición y sonido.
- No coloca ni elimina bloques reales; por ahora es una manifestación visual con un pequeño impacto de energía.
- Se añadieron partículas en el origen y en el impacto del proyectil amarillo.
- Se conservan el aura de vuelo, la persecución aérea y los ataques existentes.
\nPendiente: compilar y verificar el comportamiento en Minecraft 1.20.1.

\n## Armas de energía y voz propia v7
- Añadidas espada, hacha y escoba de energía amarilla como objetos utilizables.
- Texturas pixel-art nuevas de 32x32, modelos handheld y nombres en español/inglés.
- Daño/velocidad diferenciados: espada equilibrada, hacha de alto daño y escoba más rápida.
- Declarados eventos de audio propios para voz idle, ataque y daño; no se usan sonidos de aldeanos ni de otros mods.
- Para que la voz suene, faltan los archivos OGG originales del usuario en `assets/sinestro_boss/sounds/`. El ZIP incluye instrucciones para añadirlos.
\nPendiente: compilar y probar en Minecraft 1.20.1; no se ha confirmado la compilación.
